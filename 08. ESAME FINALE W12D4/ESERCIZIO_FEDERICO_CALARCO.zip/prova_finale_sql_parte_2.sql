create database ToysGroup;
use ToysGroup;

-- creazione tabelle
CREATE TABLE product (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(25),
    category_name VARCHAR(25)
);

CREATE TABLE region (
    region_id INT PRIMARY KEY,
    region_name VARCHAR(25)
);

CREATE TABLE sales (
    sales_id INT PRIMARY KEY,
    product_id INT,
    CONSTRAINT FK_sales_product FOREIGN KEY (product_id)
        REFERENCES product (product_id),
    region_id INT,
    CONSTRAINT FK_sales_region FOREIGN KEY (region_id)
        REFERENCES region (region_id),
    quantity INT,
    sales_amount DECIMAL(10 , 2 ),
    sales_date date
);

-- popolamento tabelle
insert into product value
(1,'lego','construction'),
(2,'orsacchiotto','peluche'),
(3,'puzzle','logic'),
(4,'rubik_cube','logic'),
(5,'cluedo','table_game');

insert into region value
(1,'calabria'),
(2,'puglia'),
(3,'campania'),
(4,'lazio'),
(5,'sicilia');

insert into sales value
(1,1,1,150,20,'1980-01-01'),
(2,2,2,200,10,'1985-02-02'),
(3,3,3,300,15,'1990-03-03'),
(4,4,3,50,5,'1990-04-04'),
(5,4,4,100,5,'2000-05-05');

-- 1. Verificare che i campi definiti come PK siano univoci.
SELECT 
    product_id
FROM
    product
GROUP BY product_id
HAVING COUNT(product_id) > 1;

SELECT 
    sales_id
FROM
    sales
GROUP BY sales_id
HAVING COUNT(sales_id) > 1;

SELECT 
    region_id
FROM
    region
GROUP BY region_id
HAVING COUNT(region_id) > 1;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT 
    p.product_name AS product_name,
    SUM(s.sales_amount) AS total_sales_amount,
    YEAR(s.sales_date) AS sales_year
FROM
    product p
        JOIN
    sales s ON p.product_id = s.product_id
GROUP BY product_name , sales_year;


-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT 
    r.region_name AS region_name,
    SUM(s.sales_amount) AS total_sales_amount,
    YEAR(s.sales_date) AS sales_year
FROM
    region r
        JOIN
    sales s ON r.region_id = s.region_id
GROUP BY region_name, sales_year
ORDER BY sales_year , total_sales_amount DESC;

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
/* è 'logica' per un totale di 450 quantità vendute */

SELECT 
    p.category_name AS category_name,
    SUM(s.quantity) AS total_quantity
FROM
    product p
        JOIN
    sales s ON p.product_id = s.product_id
GROUP BY category_name
ORDER BY total_quantity DESC
LIMIT 1; 

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
/* c'è solamente 1 prodotto invenduto ed è 'cluedo' */
SELECT 
    p.product_id AS product_product_id,
    p.product_name AS product_name,
    ifnull(s.product_id, 'TROVATO') as sales_product_id
FROM
    product p
        LEFT JOIN
    sales s ON p.product_id = s.product_id;
-- approccio n.1: sto usando IFNULL per visualizzare un valore segnaposto, 'TROVATO', per i prodotti invenduti e  la colonna sales_product_id serve a mostrare il valore NULL dove non ci sono vendite.

SELECT 
    product.product_id AS product_id,
    product.product_name AS product_name
FROM
    product
WHERE
    product_id NOT IN (SELECT 
            product_id
        FROM
            sales);
-- approccio n.2: in questa seconda query ho identificato il prodotto invenduto tramite l'utilizzo della subquery.

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    p.product_id AS product_id,
    p.product_name AS product_name,
    MAX(s.sales_date) AS sales_date
FROM
    product p
        JOIN
    sales s ON p.product_id = s.product_id
GROUP BY product_id , product_name
ORDER BY sales_date DESC;
